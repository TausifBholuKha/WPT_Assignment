Addition=((a,b)=>{
    return Number(a)+Number(b);
})
Subtraction=((a,b)=>{
    return Number(a)-Number(b);
})
Multiplication=((a,b)=>{
    return Number(a)*Number(b);
})
Division=((a,b)=>{
    return Number(a)/Number(b);
})

module.exports={Addition,Subtraction,Multiplication,Division}